## Para compilar
De momento es con `gcc -o board auth.c board.c client.c -lssl -lcrypto -Wno-deprecated-declarations` y `gcc -o server server.c`